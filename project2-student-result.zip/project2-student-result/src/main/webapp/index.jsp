<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page info="Student Result System - Input Page" %>
<%-- Declaration scripting element --%>
<%!
    String pageTitle = "Student Result Display System";
    String[] sampleIds = {"S001","S002","S003","S004","S005"};
%>
<!DOCTYPE html>
<html>
<head>
    <title><%= pageTitle %></title>
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Segoe UI',sans-serif;background:linear-gradient(135deg,#1565c0,#0d47a1);min-height:100vh;display:flex;align-items:center;justify-content:center}
        .card{background:white;padding:40px;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.2);width:420px}
        h1{text-align:center;color:#1565c0;margin-bottom:8px;font-size:22px}
        .subtitle{text-align:center;color:#666;font-size:14px;margin-bottom:30px}
        .form-group{margin-bottom:20px}
        label{display:block;font-weight:600;margin-bottom:8px;color:#333}
        input[type=text]{width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:6px;font-size:16px;text-align:center;letter-spacing:4px;text-transform:uppercase}
        input:focus{outline:none;border-color:#1565c0}
        button{width:100%;padding:12px;background:#1565c0;color:white;border:none;border-radius:6px;font-size:16px;cursor:pointer;font-weight:bold}
        .hint{margin-top:20px;text-align:center;font-size:13px;color:#666}
        .ids{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-top:8px}
        .id-badge{background:#e3f2fd;color:#1565c0;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:bold}
        .error{background:#ffebee;color:#c62828;padding:12px;border-radius:6px;margin-bottom:16px;text-align:center}
    </style>
</head>
<body>
<div class="card">
    <h1>&#127891; <%= pageTitle %></h1>
    <p class="subtitle">Enter Student ID to view result</p>
    <%-- Scriptlet scripting element --%>
    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="error"><%= error %></div>
    <% } %>
    <form action="result" method="post">
        <div class="form-group">
            <label for="sid">Student ID</label>
            <input type="text" id="sid" name="studentId" placeholder="e.g. S001" required maxlength="10"/>
        </div>
        <button type="submit">View Result &rarr;</button>
    </form>
    <div class="hint">
        <p>Available IDs:</p>
        <div class="ids">
            <% for (String id : sampleIds) { %>
                <span class="id-badge"><%= id %></span>
            <% } %>
        </div>
    </div>
</div>
</body>
</html>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.Date" %>
<%-- Declaration scripting element: methods usable in JSP --%>
<%!
    String getGrade(int m){
        if(m>=90) return "A+"; if(m>=80) return "A";
        if(m>=70) return "B";  if(m>=60) return "C";
        if(m>=40) return "D";  return "F";
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Student Result Card</title>
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Segoe UI',sans-serif;background:#f0f4f8}
        header{background:#1565c0;color:white;padding:20px 40px;text-align:center}
        .container{max-width:700px;margin:30px auto;padding:0 20px}
        .card{background:white;border-radius:10px;padding:30px;box-shadow:0 2px 8px rgba(0,0,0,.1);margin-bottom:20px}
        .student-info{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
        .student-name{font-size:24px;font-weight:bold;color:#1565c0}
        .sid{background:#e3f2fd;color:#1565c0;padding:4px 12px;border-radius:12px;font-size:14px}
        table{width:100%;border-collapse:collapse}
        th{background:#f5f5f5;padding:10px 14px;text-align:left;font-size:13px;color:#666;text-transform:uppercase}
        td{padding:12px 14px;border-bottom:1px solid #f0f0f0}
        .bar{height:12px;border-radius:6px;background:#e3f2fd;overflow:hidden}
        .bar-fill{height:100%;border-radius:6px}
        .grade{padding:3px 10px;border-radius:10px;font-weight:bold;font-size:13px}
        .summary{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-top:20px}
        .summary-item{text-align:center;background:#f5f5f5;padding:16px;border-radius:8px}
        .summary-item .lbl{font-size:12px;color:#666;text-transform:uppercase;margin-bottom:6px}
        .summary-item .val{font-size:22px;font-weight:bold;color:#1565c0}
        .banner{text-align:center;padding:20px;border-radius:10px;margin-bottom:20px}
        .pass{background:#e8f5e9;border:2px solid #2e7d32}
        .fail{background:#ffebee;border:2px solid #c62828}
        .pass .rt{font-size:28px;font-weight:bold;color:#2e7d32}
        .fail .rt{font-size:28px;font-weight:bold;color:#c62828}
        .back-btn{display:block;text-align:center;padding:12px;background:#1565c0;color:white;text-decoration:none;border-radius:6px;font-weight:bold}
        .ts{text-align:right;font-size:12px;color:#aaa;margin-top:8px}
    </style>
</head>
<body>
<header><h1>&#127891; Student Result Card</h1></header>
<div class="container">
<%-- Scriptlet scripting elements --%>
<%
    String name    = (String)  request.getAttribute("name");
    String sid     = (String)  request.getAttribute("studentId");
    int    math    = (Integer) request.getAttribute("math");
    int    science = (Integer) request.getAttribute("science");
    int    english = (Integer) request.getAttribute("english");
    int    total   = (Integer) request.getAttribute("total");
    String avg     = (String)  request.getAttribute("average");
    String status  = (String)  request.getAttribute("status");
    boolean pass   = "PASS".equals(status);
%>
<div class="banner <%= pass ? "pass" : "fail" %>">
    <div class="rt"><%= pass ? "✓ PASS" : "✗ FAIL" %></div>
    <p style="margin-top:6px;color:#555">Minimum passing marks: 40 per subject</p>
</div>
<div class="card">
    <div class="student-info">
        <div class="student-name"><%= name %></div>
        <span class="sid">ID: <%= sid %></span>
    </div>
    <table>
        <tr><th>Subject</th><th>Marks (/100)</th><th style="width:40%">Performance</th><th>Grade</th></tr>
        <%
            int[]    marks    = {math, science, english};
            String[] subjects = {"Mathematics","Science","English"};
            String[] colors   = {"#1565c0","#2e7d32","#6a1b9a"};
            for (int i = 0; i < 3; i++) {
                boolean sp = marks[i] >= 40;
        %>
        <tr>
            <td><strong><%= subjects[i] %></strong></td>
            <td style="font-size:18px;font-weight:bold;color:<%= sp?"#333":"#c62828" %>"><%= marks[i] %></td>
            <td><div class="bar"><div class="bar-fill" style="width:<%= marks[i] %>%;background:<%= colors[i] %>"></div></div></td>
            <td><span class="grade" style="background:<%= sp?"#e8f5e9":"#ffebee" %>;color:<%= sp?"#2e7d32":"#c62828" %>"><%= getGrade(marks[i]) %></span></td>
        </tr>
        <% } %>
    </table>
    <div class="summary">
        <div class="summary-item"><div class="lbl">Total</div><div class="val"><%= total %><span style="font-size:14px;color:#999">/300</span></div></div>
        <div class="summary-item"><div class="lbl">Average</div><div class="val"><%= avg %></div></div>
        <div class="summary-item"><div class="lbl">Percentage</div><div class="val"><%= String.format("%.1f",(total/300.0)*100) %>%</div></div>
    </div>
    <%-- Expression scripting element --%>
    <p class="ts">Generated: <%= new Date() %></p>
</div>
<a href="index.jsp" class="back-btn">&larr; Check Another Student</a>
</div>
</body>
</html>

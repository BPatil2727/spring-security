package com.student.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {

    record StudentData(String name, int math, int science, int english) {}

    private static final Map<String, StudentData> DB = new HashMap<>();
    static {
        DB.put("S001", new StudentData("Alice Johnson", 88, 92, 76));
        DB.put("S002", new StudentData("Bob Smith",     45, 38, 50));
        DB.put("S003", new StudentData("Carol White",   95, 89, 98));
        DB.put("S004", new StudentData("David Lee",     60, 55, 72));
        DB.put("S005", new StudentData("Eve Davis",     30, 40, 25));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String id = req.getParameter("studentId").trim().toUpperCase();
        StudentData d = DB.get(id);

        if (d == null) {
            req.setAttribute("error", "Student ID '" + id + "' not found. Try S001–S005.");
            req.getRequestDispatcher("/index.jsp").forward(req, res);
            return;
        }

        int total       = d.math() + d.science() + d.english();
        double avg      = total / 3.0;
        boolean pass    = d.math() >= 40 && d.science() >= 40 && d.english() >= 40;

        req.setAttribute("studentId", id);
        req.setAttribute("name",      d.name());
        req.setAttribute("math",      d.math());
        req.setAttribute("science",   d.science());
        req.setAttribute("english",   d.english());
        req.setAttribute("total",     total);
        req.setAttribute("average",   String.format("%.2f", avg));
        req.setAttribute("status",    pass ? "PASS" : "FAIL");
        req.getRequestDispatcher("/result.jsp").forward(req, res);
    }
}
